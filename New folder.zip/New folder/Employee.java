import java.util.List;

public class Employee extends User {

    private final String employeeId;
    private String position;

    public Employee(String userId, String username, String password,
                    String name, String email, String employeeId, String position) {
        super(userId, username, password, name, email);
        this.employeeId = employeeId;
        this.position = position;
    }

    public String getEmployeeId() { return employeeId; }
    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }


    public void viewCustomerAccounts(Customer customer) {
        if (customer == null) {
            System.out.println("Customer not found.");
            return;
        }
        System.out.println("Accounts for " + customer.getName());
        List<Account> accounts = customer.getAccounts();

        if (accounts.isEmpty()) {
            System.out.println("This customer currently has no open accounts.");
            return;
        }


        for (Account acc : accounts) {
            System.out.println("Account Number: " + acc.getAccountNumber() + ", Type: " + acc.getClass().getSimpleName() +
                    ", Balance: $" + acc.getBalance() + ", status: " + acc.getStatus());
        }
    }

    public Customer searchCustomer(Bank bank, String username) {
        User User = bank.findUser(username);
        if (User.getClass() != Customer.class) {
            System.out.println("No username as such was found" );
            return null;
        }
        System.out.println(User.getName());
        return (Customer) User;
    }

    public void generateReport(Bank bank) {
        if (bank == null) {
            System.out.println("Connection to a bank database was a failure, please insert a bank");
            return;
        }
        System.out.println("System Report: ");
        System.out.println("Total Users in System: " + bank.getUsers().size());
        System.out.println("Total Active Accounts: " + bank.getAccounts().size());
        System.out.println("Transactions Processed: " + bank.getTransactions().size());
    }
}












